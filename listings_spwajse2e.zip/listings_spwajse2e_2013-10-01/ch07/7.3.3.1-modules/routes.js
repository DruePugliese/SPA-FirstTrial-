module.exports = function () {
  console.log( 'You have included the routes module.' );
};
